rm -r EXP PF MLWDF
rm *~
