rm -r output
rm *~
